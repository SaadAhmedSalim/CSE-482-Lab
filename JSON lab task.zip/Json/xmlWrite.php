<?php

if($_GET['name']!= ''&& $_GET['username']!= ''&& $_GET['password']!= ''
&& $_GET['retypepassword']!= ''&&  $_GET['gender']!= ''&&
 $_GET['programmingskills']!= ''&&  $_GET['contactno']!= ''&& $_GET['email'] &&
 $_GET['college']!= '')
 {
    




 }















 ?>
